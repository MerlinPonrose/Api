package RestAssured.RestAssured;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PUT_Authorization {
	
	@Test
	public void put()
	{
		
		RestAssured.baseURI="https://gorest.co.in/public/v2/users";
		
		RequestSpecification httprequest = RestAssured.given();
		
		httprequest.header("Content-Type", "application/json");
		
		String token = "d35afdaf334f8b6e975c19a88ea20f65f1b85e66465f76a0c1f6a26e68dfa8b7";
		
		httprequest.header("Authorization","Bearer "+token);
		
		JSONObject data = new JSONObject();
		data.put("name", "Test User2");
		data.put("email", "test37@schaefer12.test");
		data.put("gender", "female");
		data.put("status", "active");
		
		httprequest.body(data);
		
		Response response = httprequest.request(Method.PUT,"/6101028");
		
		String res = response.getBody().asString();
		
		System.out.println(res);
		
		int statusCode = response.getStatusCode();
		
		System.out.println(statusCode);
		
		if(statusCode==200)
		{
			System.out.println("valid code");
		}
		else
		{
			System.out.println("invalid");
		}
		
		String statusLine = response.getStatusLine();
		
		System.out.println(statusLine);
		
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");
		
		String statuss = response.getBody().jsonPath().getString("status");
		
		SoftAssert soft = new SoftAssert();
		
		soft.assertEquals(statuss, "active");
		
	soft.assertAll();
		
	}

}
