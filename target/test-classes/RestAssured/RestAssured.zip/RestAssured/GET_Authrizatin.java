package RestAssured.RestAssured;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GET_Authrizatin {

	@Test
	public void getAuth(){
		// TODO Auto-generated method stub
		
		RestAssured.baseURI = "https://gorest.co.in/public/v2/users";
		
		//specify request
		
		RequestSpecification httprequest = RestAssured.given();
		
		String tkn = "d35afdaf334f8b6e975c19a88ea20f65f1b85e66465f76a0c1f6a26e68dfa8b7";
		
		httprequest.header("Authorization","Bearer "+tkn);
		
		Response respnse = httprequest.request(Method.GET,"/6078724");
		
		String res = respnse.getBody().asString();
		
		System.out.println(res);
		
		String genderrr = respnse.getBody().jsonPath().getString("gender");
		
	Assert.assertEquals(genderrr, "female");

	}

}
